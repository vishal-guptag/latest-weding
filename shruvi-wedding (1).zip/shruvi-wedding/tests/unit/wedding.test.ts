import { describe, it, expect } from 'vitest';
import { weddingDetails } from '../../src/data/weddingDetails';
import { getTimeLeft } from '../../src/utils/countdown';
import { buildIcs, googleCalendarUrl } from '../../src/utils/ics';
import { buildShareMessage, buildWhatsAppUrl } from '../../src/utils/share';

describe('event data', () => {
  it('has exactly 6 events on 11 and 12 Dec 2026 only', () => {
    expect(weddingDetails.events).toHaveLength(6);
    for (const e of weddingDetails.events) expect(['2026-12-11', '2026-12-12']).toContain(e.date);
  });
  it('has no 10 December anywhere in data, ics, share text', () => {
    const blob = JSON.stringify(weddingDetails) + buildIcs() + buildShareMessage();
    expect(blob).not.toMatch(/2026-12-10|20261210|10 December|10th December/i);
  });
  it('keeps family lists complete and ordered', () => {
    expect(weddingDetails.family.rsvp).toHaveLength(6);
    expect(weddingDetails.family.special).toHaveLength(3);
    expect(weddingDetails.family.wbcf).toHaveLength(9);
    expect(weddingDetails.family.phones).toEqual(['9760121236', '8077795772']);
  });
  it('uses D/o for the bride', () => {
    expect(weddingDetails.invite.brideLine.startsWith('D/o')).toBe(true);
  });
});

describe('countdown', () => {
  const t = weddingDetails.countdownTarget;
  it('targets IST midnight', () => expect(new Date(t).toISOString()).toBe('2026-12-11T18:30:00.000Z'));
  it('counts down', () => {
    const r = getTimeLeft(t, new Date(t).getTime() - (2 * 86400 + 3 * 3600 + 4 * 60 + 5) * 1000);
    expect(r).toEqual({ days: 2, hours: 3, minutes: 4, seconds: 5, done: false });
  });
  it('is done on and after the date', () => {
    expect(getTimeLeft(t, new Date(t).getTime()).done).toBe(true);
    expect(getTimeLeft(t, new Date(t).getTime() + 1e6).done).toBe(true);
  });
});

describe('ics', () => {
  const ics = buildIcs();
  it('has 6 events with IST times and alarms', () => {
    expect(ics.match(/BEGIN:VEVENT/g)).toHaveLength(6);
    expect(ics.match(/BEGIN:VALARM/g)).toHaveLength(6);
    expect(ics).toContain('DTSTART;TZID=Asia/Kolkata:20261211T090000');
    expect(ics).toContain('DTSTART;TZID=Asia/Kolkata:20261212T200000');
    expect(ics).toContain('\r\n');
  });
  it('builds a google calendar link', () => {
    const u = googleCalendarUrl(weddingDetails.events[0]);
    expect(u).toContain('ctz=Asia%2FKolkata');
    expect(u).toContain('20261211T090000');
  });
});

describe('share', () => {
  it('round-trips the message through the WhatsApp URL', () => {
    const url = buildWhatsAppUrl('https://example.com/');
    expect(url.startsWith('https://wa.me/?text=')).toBe(true);
    const decoded = decodeURIComponent(url.replace('https://wa.me/?text=', ''));
    expect(decoded).toBe(buildShareMessage('https://example.com/'));
    expect(decoded).toContain('💍');
    expect(decoded).toContain('\n\n');
  });
});

describe('venue urls', () => {
  it('match the spec exactly', () => {
    expect(weddingDetails.venue.locationUrl).toBe('https://www.google.com/maps/search/?api=1&query=Meraki+Hotel+%26+Banquets+Partapur+Meerut');
    expect(weddingDetails.venue.directionsUrl).toBe('https://www.google.com/maps/dir/?api=1&destination=Meraki+Hotel+%26+Banquets+Partapur+Meerut');
  });
});

describe('ics escaping', () => {
  it('escapes commas and semicolons in text fields', () => {
    const ics = buildIcs();
    expect(ics).toContain('LOCATION:Meraki Hotel & Banquets\\, Delhi Road\\, Beside');
  });
});
