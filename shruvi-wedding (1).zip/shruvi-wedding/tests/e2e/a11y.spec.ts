import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

for (const [w, h] of [[375, 812], [1366, 768]]) {
  test(`axe: no serious/critical issues at ${w}x${h}`, async ({ page }) => {
    await page.setViewportSize({ width: w, height: h });
    await page.goto('/');
    await page.getByRole('button', { name: 'Skip' }).click();
    await page.waitForTimeout(2500);
    const r = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa']).analyze();
    const bad = r.violations.filter((v) => v.impact === 'serious' || v.impact === 'critical');
    console.log('AXE>>' + JSON.stringify(bad.map((v) => ({ id: v.id, impact: v.impact, n: v.nodes.length, t: v.nodes.slice(0,3).map((n) => n.target + ' :: ' + (n.any[0]?.message ?? n.failureSummary?.slice(0,160))) }))));
    expect(bad).toEqual([]);
  });
}
