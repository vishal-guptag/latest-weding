import { test, expect, type Page } from '@playwright/test';

const viewports = [
  { w: 375, h: 812 }, { w: 768, h: 1024 }, { w: 1366, h: 768 }, { w: 1920, h: 1080 },
];

async function openSite(page: Page) {
  await page.goto('/');
  await page.getByRole('button', { name: 'Skip' }).click();
  await expect(page.getByRole('dialog', { name: /envelope/i })).toBeHidden();
}

test('envelope: open flow reveals the site', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByText('|| श्री गणेशाय नमः ||').first()).toBeVisible();
  await page.getByRole('button', { name: 'Open Your Invitation ✨' }).click();
  await expect(page.getByRole('dialog', { name: /envelope/i })).toBeHidden({ timeout: 8000 });
  await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
});

for (const v of viewports) {
  test.describe(`${v.w}x${v.h}`, () => {
    test.use({ viewport: { width: v.w, height: v.h } });

    test('no horizontal scroll, no console errors, six events with correct times', async ({ page }) => {
      const errors: string[] = [];
      const failed: string[] = [];
      page.on('requestfailed', (r) => failed.push(r.url()));
      page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
      page.on('pageerror', (e) => errors.push(String(e)));
      await openSite(page);
      const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
      expect(overflow).toBeLessThanOrEqual(0);
      const expected = [
        'BAAN, 11 December 2026, 09:00 AM', 'CHAAK, 11 December 2026, 11:00 AM',
        'GHURCHARI, 12 December 2026, 03:00 PM', 'DEPARTURE OF BARAT, 12 December 2026, 06:00 PM',
        'CHADAT, 12 December 2026, 07:00 PM', 'DINNER, 12 December 2026, 08:00 PM',
      ];
      for (const label of expected) await expect(page.getByRole('article', { name: label })).toHaveCount(1);
      // Google Fonts is unreachable inside this sandbox; any OTHER failed request is a real failure.
      const nonFont = failed.filter((u) => !/fonts\.(googleapis|gstatic)\.com/.test(u));
      expect(nonFont).toEqual([]);
      const realErrors = errors.filter((e) => !(failed.length > 0 && nonFont.length === 0 && /Failed to load resource/.test(e)));
      expect(realErrors).toEqual([]);
    });

    test('venue buttons have exact URLs', async ({ page }) => {
      await openSite(page);
      await expect(page.getByRole('link', { name: /View Location/ })).toHaveAttribute('href', 'https://www.google.com/maps/search/?api=1&query=Meraki+Hotel+%26+Banquets+Partapur+Meerut');
      await expect(page.getByRole('link', { name: /Get Directions/ })).toHaveAttribute('href', 'https://www.google.com/maps/dir/?api=1&destination=Meraki+Hotel+%26+Banquets+Partapur+Meerut');
      await expect(page.getByRole('link', { name: /View Location/ })).toHaveAttribute('rel', 'noopener noreferrer');
    });
  });
}

test('share sheet, whatsapp link, copy link', async ({ page, context }) => {
  await context.grantPermissions(['clipboard-read', 'clipboard-write']);
  await openSite(page);
  await page.getByRole('button', { name: 'Share invitation' }).click();
  const wa = page.getByRole('link', { name: /Share via WhatsApp/ });
  const href = await wa.getAttribute('href');
  expect(href!.startsWith('https://wa.me/?text=')).toBe(true);
  expect(decodeURIComponent(href!)).toContain('💍 With immense joy');
  await page.getByRole('button', { name: /Copy Invitation Link/ }).click();
  await expect(page.getByRole('button', { name: /Link copied/ })).toBeVisible();
  await page.keyboard.press('Escape');
  await expect(page.getByRole('dialog', { name: 'Share invitation' })).toBeHidden();
});

test('ics download and calendar links', async ({ page }) => {
  await openSite(page);
  const [dl] = await Promise.all([page.waitForEvent('download'), page.getByRole('button', { name: /Download \.ics/ }).click()]);
  expect(dl.suggestedFilename()).toBe('shruvi-wedding.ics');
  await expect(page.getByRole('link', { name: 'Add to Google Calendar' })).toHaveAttribute('href', /calendar\.google\.com.*20261212T200000|calendar\.google\.com/);
});

test('hindi text, family names and no 10 december', async ({ page }) => {
  await openSite(page);
  const body = await page.locator('body').innerText();
  expect(body).toContain('सखियों की रात होगी, जश्न ज़रा हट के होगा।');
  expect(body).toContain('आराध्या गुप्ता, आद्विक गुप्ता, वैभव सिंघल, लक्ष्य सिंघल');
  for (const n of ['Jagdish Prasad Singhal', 'Mukesh Gupta', 'Kanchan Singhal – Nikhil Singhal', 'Aadhya Agarwal']) expect(body).toContain(n);
  expect(body).toContain('D/o Mrs. Pinky Bansal');
  expect(body).not.toMatch(/10 December/i);
  await expect(page.getByRole('link', { name: '9760121236' })).toHaveAttribute('href', 'tel:9760121236');
  await expect(page.getByRole('link', { name: '8077795772' })).toHaveAttribute('href', 'tel:8077795772');
});

test('nav anchors and back-to-top', async ({ page }) => {
  await page.setViewportSize({ width: 1366, height: 768 });
  await openSite(page);
  await page.getByRole('navigation', { name: 'Primary' }).getByRole('link', { name: 'Venue' }).click();
  await expect(page.locator('#venue')).toBeInViewport();
  await page.getByRole('navigation', { name: 'Primary' }).getByRole('link', { name: 'RSVP' }).click();
  await expect(page.locator('#rsvp')).toBeInViewport();
  await page.getByRole('button', { name: 'Back to top' }).click();
  await expect.poll(() => page.evaluate(() => window.scrollY)).toBeLessThan(50);
});

test('pinned horizontal journey: keyboard controls move the track', async ({ page }) => {
  await page.setViewportSize({ width: 1024, height: 768 });
  await openSite(page);
  const next = page.getByRole('button', { name: 'Next event' }).first();
  await next.scrollIntoViewIfNeeded();
  const y0 = await page.evaluate(() => window.scrollY);
  await next.focus();
  await page.keyboard.press('Enter');
  await expect.poll(() => page.evaluate(() => window.scrollY)).toBeGreaterThan(y0);
});

test('reduced motion renders content', async ({ page }) => {
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.goto('/');
  await page.getByRole('button', { name: 'Open Your Invitation ✨' }).click();
  await expect(page.getByRole('dialog', { name: /envelope/i })).toBeHidden({ timeout: 5000 });
  await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
});

test('progressive enhancement: no startViewTransition / scroll timelines', async ({ page }) => {
  await page.addInitScript(() => {
    // @ts-expect-error simulate missing API
    document.startViewTransition = undefined;
    const orig = CSS.supports.bind(CSS);
    CSS.supports = (...a: string[]) => (String(a[0]).includes('animation-timeline') ? false : (orig as (...x: string[]) => boolean)(...a));
  });
  await openSite(page);
  await page.getByRole('button', { name: 'Share invitation' }).click();
  await expect(page.getByRole('dialog', { name: 'Share invitation' })).toBeVisible();
});

test('backdrop-filter disabled keeps nav readable', async ({ page }) => {
  await page.addStyleTag({ content: '*{backdrop-filter:none!important;-webkit-backdrop-filter:none!important}' });
  await openSite(page);
  const bg = await page.locator('header.glass').evaluate((e) => getComputedStyle(e).backgroundColor);
  expect(bg).toMatch(/rgba?\(/);
});
